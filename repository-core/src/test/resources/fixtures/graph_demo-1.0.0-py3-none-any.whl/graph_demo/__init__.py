VALUE = "installed-from-graph"
